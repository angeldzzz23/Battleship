/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

// thethe actual battleship game 

#include "Battleship.h"



 // if user user wants to quit, we ask they if they want to save the current game. 

// TODO
Battleship::Battleship(int gameType) {
    // figure out the game type 
    
    
}

// Game details: 
// Quitting
    // users can quit at any time of the game
    // if users quit, we ask them if they want to save
        // we save and then quit the game
    // the next time the user enters a two player game. We ask them if they want to continue playing the game
// Game details 
    // Each user enters five boats 
    // user 1 gets to choose the coordinates first. 
    // we keep on letting a user choose cordinates until they get a miss 
        // we display both the user's boards (each user has two boards)
        // ask user for correct input. 
        // if the user got a correct, we ask again. 
        // if the user got an incorrect input, we aks the next user 
    // 
        

void Battleship::startTwoPlayer() {
    
    // we can display a small menu for the user 
        // let them know that they can quit the game at any time and that they can save 
    
    // get the name of user 1
        // create a delay for user 2 to press so that they can pick their name
    // get the name of user 2 
    
    // create a delay for user 1 to press so that they can pick their boats
    
    // get the boats for user one
        // there are around ___ boats
        
    // create a delay for user 2 to press so that they can pick their board
    
    // get the boats for user 2
    
    
    // Here is where we will get input from the user 
    
    
}


// TODO
// Similar process as the other one 
void Battleship::startAIGame() {
    
}
