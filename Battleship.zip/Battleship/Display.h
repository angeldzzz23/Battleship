/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Display.h
 * Author: AZ
 *
 * Created on September 28, 2021, 11:02 AM
 * 
 * Version 1 - Ethan and Yanis - Display now uses GEtElement function of the board class to print out the board, also prints out misses, hits, boats, etc..
 */

#ifndef DISPLAY_H
#define DISPLAY_H
#include "Board.h"

// this class is in charged of display everything from the board

class Display {
private:
public:
    void displayboard(Board *board1);
    
};

#endif /* DISPLAY_H */

