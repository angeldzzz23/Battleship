/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NSFile.h
 * Author: AZ
 *
 * Created on September 28, 2021, 11:03 AM
 */

#ifndef NSFILE_H
#define NSFILE_H

// TODO #1 come up with properties
// TODo #2 come up with definitions 

class NSFile {

};

#endif /* NSFILE_H */

